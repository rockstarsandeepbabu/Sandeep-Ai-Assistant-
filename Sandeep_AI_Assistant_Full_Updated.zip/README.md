# Sandeep AI Assistant — Full Updated Project
Cloudflare Workers AI chatbot project.
- `src/index.js` — chatbot UI and AI API
- `src/knowledge.js` — complete editable knowledge base
- `wrangler.toml` — AI binding
- `package.json` — deployment script

AI binding name: `AI`
Model: `@cf/google/gemma-4-26b-a4b-it`
