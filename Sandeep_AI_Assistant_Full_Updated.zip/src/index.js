import { KNOWLEDGE } from "./knowledge.js";

const SYSTEM_PROMPT = `आप Sandeep AI Assistant हैं — ढा़ढ़वा पंचायत का डिजिटल जन-सहायक।
Knowledge Base को प्राथमिक संदर्भ मानें। सरल हिंदी में सीधे उत्तर दें।
जानकारी न मिले तो गढ़ें नहीं; कहें कि पुष्टि उपलब्ध नहीं है और 9798609313 पर संपर्क करें।
OTP/PIN/CVV/पासवर्ड न मांगें। बैंक खाता खोलने की सेवा उपलब्ध नहीं है।
Knowledge Base:
${KNOWLEDGE}`;

function page(){return `<!doctype html><html lang="hi"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sandeep AI Assistant</title>
<style>body{font-family:system-ui,sans-serif;margin:0;background:#f5f7fb;color:#172033}.wrap{max-width:760px;margin:auto;padding:18px}.card{background:#fff;border-radius:18px;padding:18px;box-shadow:0 4px 20px #0001}h1{margin:0 0 6px}.sub{color:#596579}#chat{min-height:360px;margin:18px 0}.m{padding:12px 14px;border-radius:14px;margin:10px 0;white-space:pre-wrap}.u{background:#e9f1ff;margin-left:12%}.a{background:#f0f2f5;margin-right:12%}.row{display:flex;gap:8px}.row input{flex:1;padding:13px;border:1px solid #ccd3df;border-radius:12px;font-size:16px}.row button{padding:13px 18px;border:0;border-radius:12px}.small{font-size:13px;color:#697386;margin-top:12px}</style>
</head><body><div class="wrap"><div class="card">
<h1>🤖 Sandeep AI Assistant</h1><div class="sub">ढा़ढ़वा पंचायत का डिजिटल जन-सहायक</div>
<div id="chat"><div class="m a">नमस्ते! 🙏 अपनी समस्या या जानकारी नीचे लिखें, मैं सहायता करूँगा।</div></div>
<div class="row"><input id="q" placeholder="अपना सवाल लिखें..." onkeydown="if(event.key==='Enter')send()"><button onclick="send()">भेजें</button></div>
<div class="small">WhatsApp: 9798609313 · Sandeep Digital Seva · सुबह 9 बजे–शाम 7 बजे</div>
</div></div>
<script>
async function send(){const i=document.getElementById('q'),q=i.value.trim();if(!q)return;const c=document.getElementById('chat');c.innerHTML+=`<div class="m u">${esc(q)}</div><div class="m a" id="wait">सोच रहा हूँ…</div>`;i.value='';try{const r=await fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:q})});const d=await r.json();document.getElementById('wait').textContent=d.reply||d.error||'उत्तर नहीं मिला।'}catch(e){document.getElementById('wait').textContent='अभी सेवा उपलब्ध नहीं है। कृपया 9798609313 पर संपर्क करें।'}}
function esc(s){return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
</script></body></html>`}

export default {async fetch(request,env){const url=new URL(request.url);
if(request.method==="GET")return new Response(page(),{headers:{"content-type":"text/html;charset=UTF-8"}});
if(request.method==="POST"&&url.pathname==="/api/chat"){try{const b=await request.json();const message=String(b.message||"").trim();if(!message)return Response.json({error:"सवाल लिखिए।"},{status:400});
const result=await env.AI.run("@cf/google/gemma-4-26b-a4b-it",{messages:[{role:"system",content:SYSTEM_PROMPT},{role:"user",content:message}],max_tokens:600});
return Response.json({reply:result?.response||"माफ कीजिए, अभी उत्तर नहीं मिल पाया।"});}catch(e){return Response.json({error:"AI सेवा में अभी समस्या है। कृपया थोड़ी देर बाद प्रयास करें।"},{status:500})}}
return new Response("Not found",{status:404})}};
